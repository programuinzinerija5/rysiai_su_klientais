﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Rysiai_su_klientais
{
    public class Program
    {
        // Sąrašas, kuriame programa kaupia duomenis apie klientus
        public static List<Klientas> klientai = new List<Klientas>();
        public static List<Klientas> gimtadienininkai = RastiGimtadienius(klientai);
        public static List<Klientas> varduvininkai = RastiVardadienius(klientai);



        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            KlientaiIsFailo(klientai);
            pradinis_langas pradinisLangas = new pradinis_langas();
            Application.Run(pradinisLangas);
        }

        // Metodas užkoduoja (encrypt) slaptažodį
        static public string Užkoduoti(string slaptažodis)
        {
            using (MD5CryptoServiceProvider md = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                byte[] hashas = md.ComputeHash(utf8.GetBytes(slaptažodis));
                return Convert.ToBase64String(hashas);
            }
        }

        // Metodas įkelia turimų vartotojų duomenis iš failo į programą
        static void KlientaiIsFailo(List<Klientas> klientai)
        {
            klientai.Add(new Klientas("admin", Užkoduoti("admin"), "admin", "admin", "admin", "admin", "admin", "2020-03-03"));
            string[] eilutes = File.ReadAllLines(@"Klientų duomenys.txt");
            foreach (string eilute in eilutes)
            {
                string[] duomenys = eilute.Split(' ');
                duomenys[8] = duomenys[8].Replace("\"", string.Empty);
                duomenys[8] = duomenys[8].Replace("_", " ");
                klientai.Add(new Klientas(duomenys[0], duomenys[1], duomenys[2],
                duomenys[3], duomenys[4], duomenys[5], duomenys[6], duomenys[7], duomenys[8]));
            }
            RikiuotiKlientus(klientai);
            RastiGimtadienius(klientai);
            RastiArtimiausiaVardadieni(klientai[0]);

            // Jei reikia užkoduoti esamų vartotojų slaptažodžius
            //for (int i = 1; i < klientai.Count - 1; i++)
            //{
            //string pastaba = duomenu_langas[7, i].Value.ToString();
            //Program.klientai[i].Pastabos = pastaba;
            //pastaba = pastaba.Replace(" ", "_");
            //        string hashas = Užkoduoti(klientai[i].Slaptazodis);
            //        klientai[i].Slaptazodis = hashas;
            //        eilutes[i - 1] = klientai[i].PrisijungimoVardas + " " + klientai[i].Slaptazodis + " " + klientai[i].Vardas + " "
            //            + klientai[i].Pavarde + " " + klientai[i].EPastas + " " + klientai[i].Miestas + " "
            //            + klientai[i].TelefonoNr + " " + klientai[i].Gimtadienis + " \"" + pastaba + "\"";
            //}
            //File.WriteAllLines(@"Klientų duomenys.txt", eilutes);
        }

        // Metodas rikiuoja klientų sąrašą pagal vardą ir pavardę
        static void RikiuotiKlientus(List<Klientas> klientai)
        {
            for (int i = 0; i < klientai.Count; i++)
            {
                for (int j = i + 1; j < klientai.Count; j++)
                {
                    if (string.Compare(klientai[i].Vardas, klientai[j].Vardas) == 1)
                    {
                        Klientas temp = klientai[j];
                        klientai[j] = klientai[i];
                        klientai[i] = temp;
                    }
                    else if ((string.Compare(klientai[i].Vardas, klientai[j].Vardas) == 0) && (string.Compare(klientai[i].Pavarde, klientai[j].Pavarde) == 1))
                    {
                        Klientas temp = klientai[j];
                        klientai[j] = klientai[i];
                        klientai[i] = temp;
                    }
                }
            }
        }
        
        // Metodas suranda visus klientus, kurie šiandien švenčia gimtadienį
        public static List<Klientas> RastiGimtadienius(List<Klientas> klientai)
        {
            List<Klientas> gimtadienininkai = new List<Klientas>();
            foreach (Klientas klientas in klientai)
            {
                string[] gimtadienis = klientas.Gimtadienis.Split('-');
                if ((Convert.ToInt32(gimtadienis[1]) == DateTime.Today.Month)&&(Convert.ToInt32(gimtadienis[2]) == DateTime.Today.Day))
                {
                    gimtadienininkai.Add(klientas);
                }
                
            
            }
            return gimtadienininkai;
        }

        public static List<Klientas> RastiVardadienius(List<Klientas> klientai)
        {
            List<Klientas> varduvininkai = new List<Klientas>();

            foreach (Klientas klientas in klientai)
            {
                string[] vardadienis = RastiArtimiausiaVardadieni(klientas).Split('-');
                if (vardadienis[0] != "xx")
                {
                    if ((Convert.ToInt32(vardadienis[0]) == DateTime.Today.Month) && (Convert.ToInt32(vardadienis[1]) == DateTime.Today.Day))
                    {
                        varduvininkai.Add(klientas);
                    }
                }
            }
            return varduvininkai;
        }

        // Metodas suranda kliento artimiausią vardadienį
        public static string RastiArtimiausiaVardadieni(Klientas klientas)
        {
            string[] lines = File.ReadAllLines("Vardadieniai.txt");
            List<string> datos = new List<string>();
            List<string[]> vardai = new List<string[]>();
            foreach(string line in lines)
            {
                string[] lineSplit = line.Split('-');
                datos.Add(lineSplit[0].Replace('.','-'));
                string[] vardaiTemp = lineSplit[1].Split(' ');
                vardai.Add(vardaiTemp);
            }

            //foreach (string data in datos)
            //{
            //    Console.WriteLine(data);
            //}
            int i = 0;
            foreach (string[] vardadieniai in vardai)
            {
                if (vardadieniai.Contains(klientas.Vardas))
                {
                    string[] data = datos[i].Split('-');
                    if (Convert.ToInt32(data[0]) > DateTime.Today.Month)
                    {
                        return datos[i];
                    }
                    else if ((Convert.ToInt32(data[0]) == DateTime.Today.Month) && (Convert.ToInt32(data[1]) >= DateTime.Today.Day))
                    {
                        return datos[i];
                    }
                    else i++;
                }
                else i++;
            }
            return "xx-xx";
        }
    }
}