﻿namespace Rysiai_su_klientais
{
    partial class Atvaizdavimo_langas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent(string prisijungimoVardas)
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.duomenu_langas = new System.Windows.Forms.DataGridView();
            this.sios_dienos_gimtadieniai = new System.Windows.Forms.Button();
            this.visi_duomenys = new System.Windows.Forms.Button();
            this.vard_sarasas = new System.Windows.Forms.Button();
            this.pastaba_button = new System.Windows.Forms.Button();
            this.Vardas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pavarde = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Miestas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gimimo_diena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.El_pastas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel_nr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artimiausias_vardadienis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pastabos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.duomenu_langas)).BeginInit();
            this.SuspendLayout();
            // 
            // duomenu_langas
            // 
            this.duomenu_langas.AllowUserToDeleteRows = false;
            this.duomenu_langas.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.duomenu_langas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.duomenu_langas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.duomenu_langas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.duomenu_langas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            if (prisijungimoVardas == "admin")
            {
                this.duomenu_langas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Vardas,
            this.Pavarde,
            this.Miestas,
            this.Gimimo_diena,
            this.El_pastas,
            this.Tel_nr,
            this.artimiausias_vardadienis,
            this.pastabos});
            }
            else
            {
                this.duomenu_langas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Vardas,
            this.Pavarde,
            this.Miestas,
            this.Gimimo_diena,
            this.El_pastas,
            this.Tel_nr,
            this.artimiausias_vardadienis});
            }
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.duomenu_langas.DefaultCellStyle = dataGridViewCellStyle6;
            this.duomenu_langas.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.duomenu_langas.Location = new System.Drawing.Point(12, 12);
            this.duomenu_langas.Name = "duomenu_langas";
            this.duomenu_langas.Size = new System.Drawing.Size(1005, 366);
            this.duomenu_langas.TabIndex = 0;
            // 
            // sios_dienos_gimtadieniai
            // 
            this.sios_dienos_gimtadieniai.Location = new System.Drawing.Point(60, 409);
            this.sios_dienos_gimtadieniai.Name = "sios_dienos_gimtadieniai";
            this.sios_dienos_gimtadieniai.Size = new System.Drawing.Size(187, 35);
            this.sios_dienos_gimtadieniai.TabIndex = 1;
            this.sios_dienos_gimtadieniai.Text = "Šiandien švenčiantys gimtadienį";
            this.sios_dienos_gimtadieniai.UseVisualStyleBackColor = true;
            this.sios_dienos_gimtadieniai.Click += new System.EventHandler(this.sios_dienos_gimtadieniai_Click);
            // 
            // visi_duomenys
            // 
            this.visi_duomenys.Location = new System.Drawing.Point(598, 409);
            this.visi_duomenys.Name = "visi_duomenys";
            this.visi_duomenys.Size = new System.Drawing.Size(187, 35);
            this.visi_duomenys.TabIndex = 2;
            this.visi_duomenys.Text = "Visų klientų sąrašas";
            this.visi_duomenys.UseVisualStyleBackColor = true;
            this.visi_duomenys.Click += new System.EventHandler(this.visi_duomenys_Click);
            // 
            // vard_sarasas
            // 
            this.vard_sarasas.Location = new System.Drawing.Point(334, 409);
            this.vard_sarasas.Name = "vard_sarasas";
            this.vard_sarasas.Size = new System.Drawing.Size(187, 35);
            this.vard_sarasas.TabIndex = 3;
            this.vard_sarasas.Text = "Šiandien švenčiantys vardadienį";
            this.vard_sarasas.UseVisualStyleBackColor = true;
            this.vard_sarasas.Click += new System.EventHandler(this.vard_sarasas_Click);
            // 
            // pastaba_button
            // 
            this.pastaba_button.Location = new System.Drawing.Point(839, 409);
            this.pastaba_button.Name = "pastaba_button";
            this.pastaba_button.Size = new System.Drawing.Size(187, 35);
            this.pastaba_button.TabIndex = 5;
            this.pastaba_button.Text = "Atnaujinti pastabas";
            this.pastaba_button.UseVisualStyleBackColor = true;
            this.pastaba_button.Click += new System.EventHandler(this.pastaba_button_Click);
            // 
            // Vardas
            // 
            this.Vardas.HeaderText = "Vardas";
            this.Vardas.Name = "Vardas";
            // 
            // Pavarde
            // 
            this.Pavarde.HeaderText = "Pavardė";
            this.Pavarde.Name = "Pavarde";
            // 
            // Miestas
            // 
            this.Miestas.HeaderText = "Miestas";
            this.Miestas.Name = "Miestas";
            // 
            // Gimimo_diena
            // 
            this.Gimimo_diena.HeaderText = "Gimimo diena";
            this.Gimimo_diena.Name = "Gimimo_diena";
            // 
            // El_pastas
            // 
            this.El_pastas.HeaderText = "El. paštas";
            this.El_pastas.Name = "El_pastas";
            // 
            // Tel_nr
            // 
            this.Tel_nr.HeaderText = "Tel. nr.";
            this.Tel_nr.Name = "Tel_nr";
            // 
            // artimiausias_vardadienis
            // 
            this.artimiausias_vardadienis.HeaderText = "Artimiausias vardadienis";
            this.artimiausias_vardadienis.Name = "artimiausias_vardadienis";
            // 
            // pastabos
            // 
            this.pastabos.HeaderText = "Pastabos";
            this.pastabos.Name = "pastabos";
            // 
            // Atvaizdavimo_langas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1079, 469);
            if (prisijungimoVardas == "admin")
            {
                this.Controls.Add(this.pastaba_button);
                this.Controls.Add(this.vard_sarasas);
                this.Controls.Add(this.visi_duomenys);
                this.Controls.Add(this.sios_dienos_gimtadieniai);
            }
            this.Controls.Add(this.duomenu_langas);
            this.Name = "Atvaizdavimo_langas";
            this.Text = "Klientų duomenys";
            ((System.ComponentModel.ISupportInitialize)(this.duomenu_langas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView duomenu_langas;
        private System.Windows.Forms.Button sios_dienos_gimtadieniai;
        private System.Windows.Forms.Button visi_duomenys;
        private System.Windows.Forms.Button vard_sarasas;
        private System.Windows.Forms.Button pastaba_button;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vardas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pavarde;
        private System.Windows.Forms.DataGridViewTextBoxColumn Miestas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gimimo_diena;
        private System.Windows.Forms.DataGridViewTextBoxColumn El_pastas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel_nr;
        private System.Windows.Forms.DataGridViewTextBoxColumn artimiausias_vardadienis;
        private System.Windows.Forms.DataGridViewTextBoxColumn pastabos;
    }
}