﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rysiai_su_klientais
{
    public partial class Atvaizdavimo_langas : Form
    {
        public Atvaizdavimo_langas(string prisijungimoVardas)
        {
            InitializeComponent(prisijungimoVardas);
            // tusciu eiluciu idejimas testavimui, duomenu lenteles eilutes kintamasis - duomenu_langas
            // ivedimo formatas - ("nr", "vardas", "pavarde", "miestas", "gimimo diena", "el. pastas", "tel.nr", "artimiausias vard", "pastabos")
            if (prisijungimoVardas == "admin")
            {
                for (int i = 0; i < Program.klientai.Count; i++)
                    duomenu_langas.Rows.Add(Program.klientai[i].Vardas, Program.klientai[i].Pavarde, Program.klientai[i].Miestas, Program.klientai[i].Gimtadienis, Program.klientai[i].EPastas, Program.klientai[i].TelefonoNr, DateTime.Today.Year.ToString() + "-" + Program.RastiArtimiausiaVardadieni(Program.klientai[i]), Program.klientai[i].Pastabos);
            }
            else
            {
                int i = Program.klientai.FindIndex(x => x.PrisijungimoVardas == prisijungimoVardas);
                duomenu_langas.Rows.Add(Program.klientai[i].Vardas, Program.klientai[i].Pavarde, Program.klientai[i].Miestas, Program.klientai[i].Gimtadienis, Program.klientai[i].EPastas, Program.klientai[i].TelefonoNr, DateTime.Today.Year.ToString() + "-" + Program.RastiArtimiausiaVardadieni(Program.klientai[i]));
            }
        }

        /*
         * Rodo gimtadieninkų duomenis
         */
        private void sios_dienos_gimtadieniai_Click(object sender, EventArgs e)
        {
           duomenu_langas.Rows.Clear();
           duomenu_langas.Refresh();
             List<Klientas> gimtadienininkai = Program.RastiGimtadienius(Program.klientai);
            for (int i = 0; i < gimtadienininkai.Count; i++)
                duomenu_langas.Rows.Add(gimtadienininkai[i].Vardas, 
                   gimtadienininkai[i].Pavarde, gimtadienininkai[i].Miestas, 
                    gimtadienininkai[i].Gimtadienis, gimtadienininkai[i].EPastas,
                    gimtadienininkai[i].TelefonoNr, DateTime.Today.Year.ToString() + "-" + 
                    Program.RastiArtimiausiaVardadieni(gimtadienininkai[i]), Program.klientai[i].Pastabos);
        }

        /*
         * Rodo varduvininkų sąrašą, reikia pakeisti "gimtadieninkai" į
         * "varduvininkai" ir ištraukti sąrašą su metodu analogiškai kaip su
         * gimtadieniais
        */
        private void vard_sarasas_Click(object sender, EventArgs e)
        {
            duomenu_langas.Rows.Clear();
            duomenu_langas.Refresh();
            List<Klientas> varduvininkai = Program.RastiVardadienius(Program.klientai);
            for (int i = 0; i < varduvininkai.Count; i++)
                duomenu_langas.Rows.Add(varduvininkai[i].Vardas,
                    varduvininkai[i].Pavarde, varduvininkai[i].Miestas,
                     varduvininkai[i].Gimtadienis, varduvininkai[i].EPastas,
                     varduvininkai[i].TelefonoNr, DateTime.Today.Year.ToString() + "-" +
                    Program.RastiArtimiausiaVardadieni(varduvininkai[i]), Program.klientai[i].Pastabos);
        }

        /*
         * Rodo visus duomenis
        */

        private void visi_duomenys_Click(object sender, EventArgs e)
        {
            duomenu_langas.Rows.Clear();
            duomenu_langas.Refresh();
            for (int i = 0; i < Program.klientai.Count; i++)
                duomenu_langas.Rows.Add(Program.klientai[i].Vardas, Program.klientai[i].Pavarde,
                    Program.klientai[i].Miestas, Program.klientai[i].Gimtadienis, 
                    Program.klientai[i].EPastas, Program.klientai[i].TelefonoNr, DateTime.Today.Year.ToString() + "-" + 
                    Program.RastiArtimiausiaVardadieni(Program.klientai[i]),Program.klientai[i].Pastabos);
        }

        private void pastaba_button_Click(object sender, EventArgs e)
        {
            string[] eilutės = File.ReadAllLines(@"Klientų duomenys.txt");

            for (int i = 1; i < Program.klientai.Count; i++)
            {
                // patikrinam ar i-tosios eilutės pastabų langelis užpildytas, jei taip,
                // pridedam pastabas
                // string pastaba - gauta reikšmė, kurią reikia pridėti
                    if (duomenu_langas[7, i].Value != null)
                    {
                        string pastaba = duomenu_langas[7, i].Value.ToString();
                        Program.klientai[i].Pastabos = pastaba;
                        pastaba = pastaba.Replace(" ", "_");
                        eilutės[i-1] = Program.klientai[i].PrisijungimoVardas + " " + Program.klientai[i].Slaptazodis + " " + Program.klientai[i].Vardas + " "
                            + Program.klientai[i].Pavarde + " " + Program.klientai[i].EPastas + " " + Program.klientai[i].Miestas + " "
                            + Program.klientai[i].TelefonoNr + " " + Program.klientai[i].Gimtadienis + " \"" + pastaba + "\"";
                    }
            }
            File.WriteAllLines(@"Klientų duomenys.txt",  eilutės);
        }
    }
}
