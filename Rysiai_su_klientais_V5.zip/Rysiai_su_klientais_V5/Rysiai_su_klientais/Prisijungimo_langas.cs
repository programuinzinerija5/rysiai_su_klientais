﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rysiai_su_klientais
{
    public partial class Prisijungimo_langas : Form
    {
        public Prisijungimo_langas()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            this.Hide();
            pradinis_langas p1 = new pradinis_langas();
            p1.ShowDialog();
            this.Close();
        }

        private void username_ivedimas_TextChanged(object sender, EventArgs e)
        {

        }

        private void prisijungti_button_Click(object sender, EventArgs e)
        {
            // Metodas tikrina, ar įvesti prisijungimo duomenys atitinka užregistruotą klientą
            if ((Program.klientai.FindIndex(x => x.PrisijungimoVardas == username_ivedimas.Text) != -1) &&
                (Program.klientai[Program.klientai.FindIndex(x => x.PrisijungimoVardas == username_ivedimas.Text)].Slaptazodis == Program.Užkoduoti(slaptazodzio_ivedimas.Text)))
            {

                this.Hide();
                Atvaizdavimo_langas atvaizdavimo_langas = new Atvaizdavimo_langas(username_ivedimas.Text);
                atvaizdavimo_langas.ShowDialog();

                

            }
            else
                MessageBox.Show("Prisijungimo duomenys neteisingi!", "Klaida");
        }
    }
}
