﻿namespace Rysiai_su_klientais
{
    partial class Registracijos_langas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registracijos_langas));
            this.username_registracija = new System.Windows.Forms.TextBox();
            this.slaptazodzis_registracija = new System.Windows.Forms.TextBox();
            this.username_label = new System.Windows.Forms.Label();
            this.password_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.slaptazodzio_pakartojimas = new System.Windows.Forms.TextBox();
            this.vard_label = new System.Windows.Forms.Label();
            this.pav_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.vardas_registracija = new System.Windows.Forms.TextBox();
            this.pavarde_registracija = new System.Windows.Forms.TextBox();
            this.elpastas_registracija = new System.Windows.Forms.TextBox();
            this.miestas_registracija = new System.Windows.Forms.TextBox();
            this.telnr_registracija = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.gim_diena_label = new System.Windows.Forms.Label();
            this.registruotis_button = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // username_registracija
            // 
            this.username_registracija.AccessibleName = "username_ivedimas";
            this.username_registracija.Location = new System.Drawing.Point(60, 66);
            this.username_registracija.Name = "username_registracija";
            this.username_registracija.Size = new System.Drawing.Size(100, 20);
            this.username_registracija.TabIndex = 15;
            // 
            // slaptazodzis_registracija
            // 
            this.slaptazodzis_registracija.AccessibleName = "slaptazodzio_ivedimas";
            this.slaptazodzis_registracija.Location = new System.Drawing.Point(60, 114);
            this.slaptazodzis_registracija.Name = "slaptazodzis_registracija";
            this.slaptazodzis_registracija.PasswordChar = '*';
            this.slaptazodzis_registracija.Size = new System.Drawing.Size(100, 20);
            this.slaptazodzis_registracija.TabIndex = 14;
            // 
            // username_label
            // 
            this.username_label.AccessibleName = "prisijungimo_vardas_lbl";
            this.username_label.AutoSize = true;
            this.username_label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.username_label.Location = new System.Drawing.Point(60, 44);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(138, 16);
            this.username_label.TabIndex = 11;
            this.username_label.Text = "Prisijungimo vardas:";
            // 
            // password_label
            // 
            this.password_label.AccessibleName = "prisijungimo_slaptazodis_lbl";
            this.password_label.AutoSize = true;
            this.password_label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.password_label.Location = new System.Drawing.Point(60, 92);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(86, 16);
            this.password_label.TabIndex = 16;
            this.password_label.Text = "Slaptažodis:";
            // 
            // label1
            // 
            this.label1.AccessibleName = "prisijungimo_slaptazodis_lbl";
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.Location = new System.Drawing.Point(60, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Pakartokite slaptažodį:";
            // 
            // slaptazodzio_pakartojimas
            // 
            this.slaptazodzio_pakartojimas.AccessibleName = "slaptazodzio_ivedimas";
            this.slaptazodzio_pakartojimas.Location = new System.Drawing.Point(60, 162);
            this.slaptazodzio_pakartojimas.Name = "slaptazodzio_pakartojimas";
            this.slaptazodzio_pakartojimas.PasswordChar = '*';
            this.slaptazodzio_pakartojimas.Size = new System.Drawing.Size(100, 20);
            this.slaptazodzio_pakartojimas.TabIndex = 18;
            // 
            // vard_label
            // 
            this.vard_label.AccessibleName = "vardas_lbl";
            this.vard_label.AutoSize = true;
            this.vard_label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.vard_label.Location = new System.Drawing.Point(60, 188);
            this.vard_label.Name = "vard_label";
            this.vard_label.Size = new System.Drawing.Size(55, 16);
            this.vard_label.TabIndex = 19;
            this.vard_label.Text = "Vardas:";
            // 
            // pav_label
            // 
            this.pav_label.AccessibleName = "vardas_lbl";
            this.pav_label.AutoSize = true;
            this.pav_label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.pav_label.Location = new System.Drawing.Point(60, 236);
            this.pav_label.Name = "pav_label";
            this.pav_label.Size = new System.Drawing.Size(65, 16);
            this.pav_label.TabIndex = 20;
            this.pav_label.Text = "Pavardė:";
            // 
            // label2
            // 
            this.label2.AccessibleName = "vardas_lbl";
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label2.Location = new System.Drawing.Point(60, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 21;
            this.label2.Text = "El. paštas:";
            // 
            // label3
            // 
            this.label3.AccessibleName = "vardas_lbl";
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label3.Location = new System.Drawing.Point(60, 332);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Miestas:";
            // 
            // label4
            // 
            this.label4.AccessibleName = "vardas_lbl";
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label4.Location = new System.Drawing.Point(60, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Telefono nr.:";
            // 
            // vardas_registracija
            // 
            this.vardas_registracija.AccessibleName = "username_ivedimas";
            this.vardas_registracija.Location = new System.Drawing.Point(60, 210);
            this.vardas_registracija.Name = "vardas_registracija";
            this.vardas_registracija.Size = new System.Drawing.Size(100, 20);
            this.vardas_registracija.TabIndex = 24;
            // 
            // pavarde_registracija
            // 
            this.pavarde_registracija.AccessibleName = "username_ivedimas";
            this.pavarde_registracija.Location = new System.Drawing.Point(60, 258);
            this.pavarde_registracija.Name = "pavarde_registracija";
            this.pavarde_registracija.Size = new System.Drawing.Size(100, 20);
            this.pavarde_registracija.TabIndex = 25;
            // 
            // elpastas_registracija
            // 
            this.elpastas_registracija.AccessibleName = "username_ivedimas";
            this.elpastas_registracija.Location = new System.Drawing.Point(60, 306);
            this.elpastas_registracija.Name = "elpastas_registracija";
            this.elpastas_registracija.Size = new System.Drawing.Size(100, 20);
            this.elpastas_registracija.TabIndex = 26;
            // 
            // miestas_registracija
            // 
            this.miestas_registracija.AccessibleName = "username_ivedimas";
            this.miestas_registracija.Location = new System.Drawing.Point(60, 354);
            this.miestas_registracija.Name = "miestas_registracija";
            this.miestas_registracija.Size = new System.Drawing.Size(100, 20);
            this.miestas_registracija.TabIndex = 27;
            // 
            // telnr_registracija
            // 
            this.telnr_registracija.AccessibleName = "username_ivedimas";
            this.telnr_registracija.Location = new System.Drawing.Point(60, 402);
            this.telnr_registracija.Name = "telnr_registracija";
            this.telnr_registracija.Size = new System.Drawing.Size(100, 20);
            this.telnr_registracija.TabIndex = 28;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(60, 450);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 29;
            // 
            // gim_diena_label
            // 
            this.gim_diena_label.AutoSize = true;
            this.gim_diena_label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.gim_diena_label.Location = new System.Drawing.Point(60, 428);
            this.gim_diena_label.Name = "gim_diena_label";
            this.gim_diena_label.Size = new System.Drawing.Size(133, 16);
            this.gim_diena_label.TabIndex = 30;
            this.gim_diena_label.Text = "Jūsų gimimo diena:";
            // 
            // registruotis_button
            // 
            this.registruotis_button.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.registruotis_button.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.registruotis_button.Location = new System.Drawing.Point(84, 507);
            this.registruotis_button.Name = "registruotis_button";
            this.registruotis_button.Size = new System.Drawing.Size(129, 33);
            this.registruotis_button.TabIndex = 31;
            this.registruotis_button.Text = "Registruotis";
            this.registruotis_button.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label5.ForeColor = System.Drawing.Color.Brown;
            this.label5.Location = new System.Drawing.Point(25, 486);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(266, 14);
            this.label5.TabIndex = 32;
            this.label5.Text = "Slaptažodį būtinai turi sudaryti bent 8 simboliai!";
            // 
            // Registracijos_langas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(299, 552);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.registruotis_button);
            this.Controls.Add(this.gim_diena_label);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.telnr_registracija);
            this.Controls.Add(this.miestas_registracija);
            this.Controls.Add(this.elpastas_registracija);
            this.Controls.Add(this.pavarde_registracija);
            this.Controls.Add(this.vardas_registracija);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pav_label);
            this.Controls.Add(this.vard_label);
            this.Controls.Add(this.slaptazodzio_pakartojimas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.password_label);
            this.Controls.Add(this.username_registracija);
            this.Controls.Add(this.slaptazodzis_registracija);
            this.Controls.Add(this.username_label);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Registracijos_langas";
            this.Text = "Registracijos_langas_cs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox username_registracija;
        private System.Windows.Forms.TextBox slaptazodzis_registracija;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox slaptazodzio_pakartojimas;
        private System.Windows.Forms.Label vard_label;
        private System.Windows.Forms.Label pav_label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox vardas_registracija;
        private System.Windows.Forms.TextBox pavarde_registracija;
        private System.Windows.Forms.TextBox elpastas_registracija;
        private System.Windows.Forms.TextBox miestas_registracija;
        private System.Windows.Forms.TextBox telnr_registracija;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label gim_diena_label;
        private System.Windows.Forms.Button registruotis_button;
        private System.Windows.Forms.Label label5;
    }
}