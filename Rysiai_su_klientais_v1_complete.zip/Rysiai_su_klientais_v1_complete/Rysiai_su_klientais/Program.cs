﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rysiai_su_klientais
{
    public class Program
    {
        public static List<Klientas> klientai = new List<Klientas>();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            KlientaiIsFailo(klientai);
            pradinis_langas pradinisLangas = new pradinis_langas();
            Application.Run(pradinisLangas);
        }

        static void KlientaiIsFailo(List<Klientas> klientai)
        {
            string[] eilutes = File.ReadAllLines(@"Klientų duomenys.txt");
            foreach(string eilute in eilutes)
            {
                string[] duomenys = eilute.Split(' ');
                klientai.Add(new Klientas(duomenys[0], duomenys[1], duomenys[2],
                duomenys[3], duomenys[4], duomenys[5], duomenys[6], duomenys[7]));
            }
        }
    }
}
