﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rysiai_su_klientais
{
    public partial class Registracijos_langas : Form
    {
        public Registracijos_langas()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
          
            this.Hide();
            pradinis_langas p1 = new pradinis_langas();
            p1.ShowDialog();
            this.Close();
        }

        private void slaptazodzio_pakartojimas_TextChanged(object sender, EventArgs e)
        {

        }

        private void registruotis_button_Click(object sender, EventArgs e)
        {
            if ((username_registracija.Text.Length >= 1) && (slaptazodis_registracija.Text.Length >= 8) &&
                (slaptazodzio_pakartojimas.Text == slaptazodis_registracija.Text) && (vardas_registracija.Text.Length >= 1) &&
                (pavarde_registracija.Text.Length >= 1) && (elpastas_registracija.Text.Length >= 1) &&
                (miestas_registracija.Text.Length >= 1) && (telnr_registracija.Text.Length >= 1) &&
                (dateTimePicker1.Value.ToShortDateString().Length >= 1) &&
                (Program.klientai.FindIndex(x => x.PrisijungimoVardas == username_registracija.Text) == -1))
            {
                string[] duomenys = new string[1];
                duomenys[0] = username_registracija.Text + " " + slaptazodis_registracija.Text + " " +
                    vardas_registracija.Text + " " + pavarde_registracija.Text + " " + elpastas_registracija.Text + " " +
                    miestas_registracija.Text + " " + telnr_registracija.Text + " " + dateTimePicker1.Value.ToShortDateString();
                string[] duomenysSplit = duomenys[0].Split(' ');
                Program.klientai.Add(new Klientas(duomenysSplit[0], duomenysSplit[1], duomenysSplit[2],
                duomenysSplit[3], duomenysSplit[4], duomenysSplit[5], duomenysSplit[6], duomenysSplit[7]));
                File.AppendAllLines(@"Klientų duomenys.txt", duomenys);
                this.Hide();
                Prisijungimo_langas login_langas = new Prisijungimo_langas();
                login_langas.ShowDialog();
            }
        }
    }
}
